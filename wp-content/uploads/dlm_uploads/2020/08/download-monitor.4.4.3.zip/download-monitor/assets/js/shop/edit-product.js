jQuery( function ( $ ) {
	$('.dlm-select-ext').select2();
});