<?php

namespace Never5\DownloadMonitor\Dependencies\PayPal\Rest;

/**
 * Interface IResource
 *
 * @package Never5\DownloadMonitor\Dependencies\PayPal\Rest
 */
interface IResource
{
}
