<?php

namespace Never5\DownloadMonitor\Dependencies\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
