<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly
?>
<p><?php _e( 'Your cart is empty.', 'download-monitor' ); ?></p>
